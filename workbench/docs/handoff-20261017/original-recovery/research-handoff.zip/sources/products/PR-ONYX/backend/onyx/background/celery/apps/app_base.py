import logging
import multiprocessing
import os
import sys
import time
from typing import Any, cast

from celery import (
    Task,
    bootsteps,
)
from celery.app import trace
from celery.exceptions import WorkerShutdown
from celery.signals import before_task_publish, task_postrun, task_prerun
from celery.states import READY_STATES
from celery.utils.log import get_task_logger
from celery.worker import strategy
from celery.worker.control import control_command
from redis.lock import Lock as RedisLock
from sentry_sdk.integrations.celery import CeleryIntegration
from sqlalchemy import text
from sqlalchemy.orm import Session

from onyx.background.celery.apps.task_formatters import (
    CeleryTaskColoredFormatter,
    CeleryTaskJsonFormatter,
    CeleryTaskPlainFormatter,
)
from onyx.background.celery.celery_utils import (
    celery_is_worker_primary,
    make_probe_path,
)
from onyx.background.celery.tasks.vespa.document_sync import (
    DOCUMENT_SYNC_PREFIX,
    DOCUMENT_SYNC_TASKSET_KEY,
)
from onyx.configs.app_configs import DISABLE_VECTOR_DB
from onyx.configs.constants import ONYX_CLOUD_CELERY_TASK_PREFIX, OnyxRedisLocks
from onyx.db.engine.sql_engine import get_sqlalchemy_engine
from onyx.redis.redis_connector import RedisConnector
from onyx.redis.redis_connector_delete import RedisConnectorDelete
from onyx.redis.redis_connector_prune import RedisConnectorPrune
from onyx.redis.redis_document_set import RedisDocumentSet
from onyx.redis.redis_pool import get_redis_client
from onyx.redis.redis_usergroup import RedisUserGroup
from onyx.tracing.setup import setup_tracing
from onyx.utils.fleet_telemetry import start_telemetry
from onyx.utils.logger import (
    ColoredFormatter,
    LoggerContextVars,
    PlainFormatter,
    cap_third_party_log_levels,
    get_json_formatter,
    get_log_level_from_str,
    setup_logger,
)
from shared_configs.configs import (
    DEV_LOGGING_ENABLED,
    JSON_LOGGING,
    MULTI_TENANT,
    POSTGRES_DEFAULT_SCHEMA,
    SENTRY_CELERY_TRACES_SAMPLE_RATE,
    SENTRY_DSN,
    TENANT_ID_PREFIX,
)
from shared_configs.contextvars import CURRENT_TENANT_ID_CONTEXTVAR

logger = setup_logger()

task_logger = get_task_logger(__name__)

if SENTRY_DSN:
    from onyx.configs.sentry import init_sentry

    init_sentry(
        traces_sample_rate=SENTRY_CELERY_TRACES_SAMPLE_RATE,
        integrations=[CeleryIntegration()],
    )
else:
    logger.debug("Sentry DSN not provided, skipping Sentry initialization")


@control_command()
def clear_revoked(state: Any, **kwargs: Any) -> dict[str, Any]:  # noqa: ARG001
    """Remote command to wipe this worker's in-memory revoked-task set.

    The set lives only in memory, propagates between workers via mingle, and its
    cross-node entries don't expire — so after a mass-revoke it can pin at its 50k
    cap and won't self-heal or clear on a rolling restart. Broadcast this to clear
    the fleet without restarting. Deliberate use only: revoked state is dropped.

    Intentionally ungated, like Celery's built-in shutdown/terminate/revoke control
    commands: the trust boundary is broker access, not a per-command check.
    """
    from celery.worker import state as worker_state

    count = len(worker_state.revoked)
    worker_state.revoked.clear()
    task_logger.warning("clear_revoked: cleared %d revoked task ids", count)
    return {"ok": f"cleared {count} revoked task ids"}


class TenantAwareTask(Task):
    """A custom base Task that sets tenant_id in a contextvar before running."""

    abstract = True  # So Celery knows not to register this as a real task.

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        # Grab tenant_id from the kwargs, or fallback to default if missing.
        tenant_id = kwargs.get("tenant_id", None) or POSTGRES_DEFAULT_SCHEMA

        # Set the context var
        CURRENT_TENANT_ID_CONTEXTVAR.set(tenant_id)

        # Actually run the task now
        try:
            return super().__call__(*args, **kwargs)
        finally:
            # Clear or reset after the task runs
            # so it does not leak into any subsequent tasks on the same worker process
            CURRENT_TENANT_ID_CONTEXTVAR.set(None)


@before_task_publish.connect
def on_before_task_publish(
    headers: dict[str, Any] | None = None,
    **kwargs: Any,  # noqa: ARG001
) -> None:
    """Stamp the current wall-clock time into the task message headers so that
    workers can compute queue wait time (time between publish and execution)."""
    if headers is not None:
        headers["enqueued_at"] = time.time()


@task_prerun.connect
def on_task_prerun(
    sender: Any | None = None,  # noqa: ARG001
    task_id: str | None = None,  # noqa: ARG001
    task: Task | None = None,  # noqa: ARG001
    args: tuple[Any, ...] | None = None,  # noqa: ARG001
    kwargs: dict[str, Any] | None = None,  # noqa: ARG001
    **other_kwargs: Any,  # noqa: ARG001
) -> None:
    # Reset any per-task logging context so that prefixes (e.g. pruning_ctx)
    # from a previous task executed in the same worker process do not leak
    # into the next task's log messages. This fixes incorrect [CC Pair:/Index Attempt]
    # prefixes observed when a pruning task finishes and an indexing task
    # runs in the same process.

    LoggerContextVars.reset()


def on_task_postrun(
    sender: Any | None = None,  # noqa: ARG001
    task_id: str | None = None,
    task: Task | None = None,
    args: tuple | None = None,  # noqa: ARG001
    kwargs: dict[str, Any] | None = None,
    retval: Any | None = None,  # noqa: ARG001
    state: str | None = None,
    **kwds: Any,  # noqa: ARG001
) -> None:
    """We handle this signal in order to remove completed tasks
    from their respective tasksets. This allows us to track the progress of document set
    and user group syncs.

    This function runs after any task completes (both success and failure)
    Note that this signal does not fire on a task that failed to complete and is going
    to be retried.

    This also does not fire if a worker with acks_late=False crashes (which all of our
    long running workers are)
    """
    if not task:
        return

    task_logger.debug(
        "Task %s (ID: %s) completed with state: %s", task.name, task_id, state
    )

    if state not in READY_STATES:
        return

    if not task_id:
        return

    if task.name.startswith(ONYX_CLOUD_CELERY_TASK_PREFIX):
        # this is a cloud / all tenant task ... no postrun is needed
        return

    # Get tenant_id directly from kwargs- each celery task has a tenant_id kwarg
    if not kwargs:
        logger.error("Task %s (ID: %s) is missing kwargs", task.name, task_id)
        tenant_id = POSTGRES_DEFAULT_SCHEMA
    else:
        tenant_id = cast(str, kwargs.get("tenant_id", POSTGRES_DEFAULT_SCHEMA))

    task_logger.debug(
        "Task %s (ID: %s) completed with state: %s %s",
        task.name,
        task_id,
        state,
        f"for tenant_id={tenant_id}" if tenant_id else "",
    )

    r = get_redis_client(tenant_id=tenant_id)

    # NOTE: we want to remove the `Redis*` classes, prefer to just have functions to
    # do these things going forward. In short, things should generally be like the doc
    # sync task rather than the others below
    if task_id.startswith(DOCUMENT_SYNC_PREFIX):
        r.srem(DOCUMENT_SYNC_TASKSET_KEY, task_id)
        return

    if task_id.startswith(RedisDocumentSet.PREFIX):
        document_set_id = RedisDocumentSet.get_id_from_task_id(task_id)
        if document_set_id is not None:
            rds = RedisDocumentSet(tenant_id, int(document_set_id))
            r.srem(rds.taskset_key, task_id)
        return

    if task_id.startswith(RedisUserGroup.PREFIX):
        usergroup_id = RedisUserGroup.get_id_from_task_id(task_id)
        if usergroup_id is not None:
            rug = RedisUserGroup(tenant_id, int(usergroup_id))
            r.srem(rug.taskset_key, task_id)
        return

    if task_id.startswith(RedisConnectorDelete.PREFIX):
        cc_pair_id = RedisConnector.get_id_from_task_id(task_id)
        if cc_pair_id is not None:
            RedisConnectorDelete.remove_from_taskset(int(cc_pair_id), task_id, r)
        return

    if task_id.startswith(RedisConnectorPrune.SUBTASK_PREFIX):
        cc_pair_id = RedisConnector.get_id_from_task_id(task_id)
        if cc_pair_id is not None:
            RedisConnectorPrune.remove_from_taskset(int(cc_pair_id), task_id, r)
        return


def on_task_revoked(
    request: Any | None = None,
    **kwds: Any,  # noqa: ARG001
) -> None:
    """Drain the doc-sync taskset when a task is revoked/expired.

    Expired tasks are discarded before running, so task_postrun (which normally
    srem's the taskset) never fires. Without this, the stranded id keeps the
    taskset non-empty and wedges the sync fence until its 7-day TTL.
    """
    task_id = getattr(request, "id", None)  # ods: ignore[getattr]
    if not task_id:
        return

    if not task_id.startswith(DOCUMENT_SYNC_PREFIX):
        return

    request_kwargs = getattr(request, "kwargs", None) or {}  # ods: ignore[getattr]
    tenant_id = cast(str, request_kwargs.get("tenant_id", POSTGRES_DEFAULT_SCHEMA))

    r = get_redis_client(tenant_id=tenant_id)
    r.srem(DOCUMENT_SYNC_TASKSET_KEY, task_id)


def on_celeryd_init(
    sender: str,  # noqa: ARG001
    conf: Any = None,  # noqa: ARG001
    **kwargs: Any,  # noqa: ARG001
) -> None:
    """The first signal sent on celery worker startup"""

    # NOTE(rkuo): start method "fork" is unsafe and we really need it to be "spawn"
    # But something is blocking set_start_method from working in the cloud unless
    # force=True. so we use force=True as a fallback.

    all_start_methods: list[str] = multiprocessing.get_all_start_methods()
    logger.info("Multiprocessing all start methods: %s", all_start_methods)

    try:
        multiprocessing.set_start_method("spawn")  # fork is unsafe, set to spawn
    except Exception:
        logger.info(
            "Multiprocessing set_start_method exceptioned. Trying force=True..."
        )
        try:
            multiprocessing.set_start_method(
                "spawn", force=True
            )  # fork is unsafe, set to spawn
        except Exception:
            logger.info(
                "Multiprocessing set_start_method force=True exceptioned even with force=True."
            )

    logger.info(
        "Multiprocessing selected start method: %s", multiprocessing.get_start_method()
    )

    # Initialize tracing in workers if credentials are available.
    setup_tracing()


def wait_for_redis(sender: Any, **kwargs: Any) -> None:  # noqa: ARG001
    """Waits for redis to become ready subject to a hardcoded timeout.
    Will raise WorkerShutdown to kill the celery worker if the timeout
    is reached."""

    r = get_redis_client(tenant_id=POSTGRES_DEFAULT_SCHEMA)

    WAIT_INTERVAL = 5
    WAIT_LIMIT = 60

    ready = False
    time_start = time.monotonic()
    logger.info("Redis: Readiness probe starting.")
    while True:
        try:
            if r.ping():
                ready = True
                break
        except Exception:
            pass

        time_elapsed = time.monotonic() - time_start
        if time_elapsed > WAIT_LIMIT:
            break

        logger.info(
            "Redis: Readiness probe ongoing. elapsed=%s timeout=%s",
            format(time_elapsed, ".1f"),
            format(WAIT_LIMIT, ".1f"),
        )

        time.sleep(WAIT_INTERVAL)

    if not ready:
        msg = f"Redis: Readiness probe did not succeed within the timeout ({WAIT_LIMIT} seconds). Exiting..."
        logger.error(msg)
        raise WorkerShutdown(msg)

    logger.info("Redis: Readiness probe succeeded. Continuing...")
    return


def wait_for_db(sender: Any, **kwargs: Any) -> None:  # noqa: ARG001
    """Waits for the db to become ready subject to a hardcoded timeout.
    Will raise WorkerShutdown to kill the celery worker if the timeout is reached."""

    WAIT_INTERVAL = 5
    WAIT_LIMIT = 60

    ready = False
    time_start = time.monotonic()
    logger.info("Database: Readiness probe starting.")
    while True:
        try:
            with Session(get_sqlalchemy_engine()) as db_session:
                result = db_session.execute(text("SELECT NOW()")).scalar()
                if result:
                    ready = True
                    break
        except Exception:
            pass

        time_elapsed = time.monotonic() - time_start
        if time_elapsed > WAIT_LIMIT:
            break

        logger.info(
            "Database: Readiness probe ongoing. elapsed=%s timeout=%s",
            format(time_elapsed, ".1f"),
            format(WAIT_LIMIT, ".1f"),
        )

        time.sleep(WAIT_INTERVAL)

    if not ready:
        msg = f"Database: Readiness probe did not succeed within the timeout ({WAIT_LIMIT} seconds). Exiting..."
        logger.error(msg)
        raise WorkerShutdown(msg)

    logger.info("Database: Readiness probe succeeded. Continuing...")
    return


def on_secondary_worker_init(sender: Any, **kwargs: Any) -> None:  # noqa: ARG001
    logger.info("Running as a secondary celery worker: pid=%s", os.getpid())

    # Set up variables for waiting on primary worker
    WAIT_INTERVAL = 5
    WAIT_LIMIT = 60
    r = get_redis_client(tenant_id=POSTGRES_DEFAULT_SCHEMA)
    time_start = time.monotonic()

    logger.info("Waiting for primary worker to be ready...")
    while True:
        if r.exists(OnyxRedisLocks.PRIMARY_WORKER):
            break

        time_elapsed = time.monotonic() - time_start
        logger.info(
            "Primary worker is not ready yet. elapsed=%s timeout=%s",
            format(time_elapsed, ".1f"),
            format(WAIT_LIMIT, ".1f"),
        )
        if time_elapsed > WAIT_LIMIT:
            msg = f"Primary worker was not ready within the timeout. ({WAIT_LIMIT} seconds). Exiting..."
            logger.error(msg)
            raise WorkerShutdown(msg)

        time.sleep(WAIT_INTERVAL)

    logger.info("Wait for primary worker completed successfully. Continuing...")
    return


def on_worker_ready(sender: Any, **kwargs: Any) -> None:  # noqa: ARG001
    start_telemetry("worker")
    task_logger.info("worker_ready signal received.")

    # file based way to do readiness/liveness probes
    # https://medium.com/ambient-innovation/health-checks-for-celery-in-kubernetes-cf3274a3e106
    # https://github.com/celery/celery/issues/4079#issuecomment-1270085680

    hostname: str = cast(str, sender.hostname)
    path = make_probe_path("readiness", hostname)
    path.touch()
    logger.info("Readiness signal touched at %s.", path)


def on_worker_shutdown(sender: Any, **kwargs: Any) -> None:  # noqa: ARG001
    hostname: str = cast(str, sender.hostname)
    path = make_probe_path("readiness", hostname)
    path.unlink(missing_ok=True)

    if not celery_is_worker_primary(sender):
        return

    if not hasattr(sender, "primary_worker_lock"):
        # primary_worker_lock will not exist when MULTI_TENANT is True
        return

    if not sender.primary_worker_lock:
        return

    logger.info("Releasing primary worker lock.")
    lock: RedisLock = sender.primary_worker_lock
    try:
        if lock.owned():
            try:
                lock.release()
                sender.primary_worker_lock = None
            except Exception:
                logger.exception("Failed to release primary worker lock")
    except Exception:
        logger.exception("Failed to check if primary worker lock is owned")


def _cli_loglevel_explicitly_set() -> bool:
    """
    Returns True iff --loglevel or -l was explicitly passed on the celery CLI.

    The setup_logging signal handler receives a ``loglevel`` int regardless of
    whether the operator actually passed --loglevel — when the flag is absent,
    Celery substitutes its own default. To distinguish "operator passed it" (CLI
    should win) from "Celery defaulted it" (LOG_LEVEL env should win) we have to
    inspect sys.argv ourselves.
    """
    for arg in sys.argv:
        if arg == "--loglevel" or arg.startswith("--loglevel="):
            return True
        # short form: ``-l VALUE``, ``-l=VALUE``, ``-lVALUE`` (the ``arg ==
        # "-l"`` case is subsumed by the startswith branch since "-l" starts
        # with "-l" and doesn't start with "--")
        if arg.startswith("-l") and not arg.startswith("--"):
            return True
    return False


def _resolve_effective_loglevel(cli_loglevel: int) -> tuple[int, str]:
    """
    Returns the (level, human-readable explanation) for celery worker logging.

    Precedence: explicit --loglevel CLI flag > LOG_LEVEL env var > Celery
    default. An operator-supplied CLI flag is treated as a per-worker
    override; otherwise LOG_LEVEL is the single global knob across the API
    server, model servers, and all Celery workers.

    Surfaces unrecognized LOG_LEVEL strings (e.g. "WARN" instead of
    "WARNING") in the source string so the operator can see in the boot
    log that their value silently fell back to INFO.
    """
    env_log_level = os.environ.get("LOG_LEVEL")
    if _cli_loglevel_explicitly_set():
        return cli_loglevel, "celery --loglevel CLI arg"
    if env_log_level is not None:
        effective = get_log_level_from_str(env_log_level)
        parsed_name = logging.getLevelName(effective)
        if parsed_name.upper() != env_log_level.upper():
            return effective, (
                f"LOG_LEVEL env var ({env_log_level!r} -> unrecognized, defaulted to {parsed_name})"
            )
        return effective, f"LOG_LEVEL env var ({env_log_level!r})"
    return cli_loglevel, "celery default (no --loglevel, no LOG_LEVEL)"


def on_setup_logging(
    loglevel: int,
    logfile: str | None,
    format: str,  # noqa: ARG001
    colorize: bool,  # noqa: ARG001
    **kwargs: Any,  # noqa: ARG001
) -> None:
    # TODO: could unhardcode format and colorize and accept these as options from
    # celery's config

    effective_loglevel, loglevel_source = _resolve_effective_loglevel(loglevel)

    root_logger = logging.getLogger()
    root_logger.handlers = []

    # Define the log format
    log_format = (
        "%(levelname)-8s %(asctime)s %(filename)15s:%(lineno)-4d: %(name)s %(message)s"
    )

    # Set up the root handler
    root_handler = logging.StreamHandler()
    root_formatter: logging.Formatter = (
        get_json_formatter()
        if JSON_LOGGING
        else ColoredFormatter(log_format, datefmt="%m/%d/%Y %I:%M:%S %p")
    )
    root_handler.setFormatter(root_formatter)
    root_logger.addHandler(root_handler)

    if logfile:
        # Truncate log file if DEV_LOGGING_ENABLED (for clean dev experience)
        if DEV_LOGGING_ENABLED and os.path.exists(logfile):
            try:
                open(logfile, "w").close()  # Truncate the file
            except Exception:
                pass  # Ignore errors, just proceed with normal logging

        root_file_handler = logging.FileHandler(logfile)
        root_file_formatter: logging.Formatter = (
            get_json_formatter()
            if JSON_LOGGING
            else PlainFormatter(log_format, datefmt="%m/%d/%Y %I:%M:%S %p")
        )
        root_file_handler.setFormatter(root_file_formatter)
        root_logger.addHandler(root_file_handler)

    root_logger.setLevel(effective_loglevel)

    # Third-party loggers inherit the root logger's level, so a DEBUG root
    # would otherwise turn their firehoses on; re-cap them against the level
    # this worker actually runs at.
    cap_third_party_log_levels(effective_loglevel)

    # Emit the diagnostic after the root logger is configured so it goes through
    # the fresh handler at the level we just chose. (Before this point Python's
    # root logger defaults to WARNING, which would silently drop an INFO message
    # in the no-LOG_LEVEL/no-CLI default case.)
    logger.info(
        "Celery effective log level: %s (source: %s)",
        logging.getLevelName(effective_loglevel),
        loglevel_source,
    )

    # Configure the task logger
    task_logger.handlers = []

    task_handler = logging.StreamHandler()
    task_handler.addFilter(TenantContextFilter())
    task_formatter: logging.Formatter = (
        CeleryTaskJsonFormatter()
        if JSON_LOGGING
        else CeleryTaskColoredFormatter(log_format, datefmt="%m/%d/%Y %I:%M:%S %p")
    )
    task_handler.setFormatter(task_formatter)
    task_logger.addHandler(task_handler)

    if logfile:
        # No need to truncate again, already done above for root logger
        task_file_handler = logging.FileHandler(logfile)
        task_file_handler.addFilter(TenantContextFilter())
        task_file_formatter: logging.Formatter = (
            CeleryTaskJsonFormatter()
            if JSON_LOGGING
            else CeleryTaskPlainFormatter(log_format, datefmt="%m/%d/%Y %I:%M:%S %p")
        )
        task_file_handler.setFormatter(task_file_formatter)
        task_logger.addHandler(task_file_handler)

    task_logger.setLevel(effective_loglevel)
    task_logger.propagate = False

    # hide celery task received spam
    # e.g. "Task check_for_pruning[a1e96171-0ba8-4e00-887b-9fbf7442eab3] received"
    strategy.logger.setLevel(logging.WARNING)

    # uncomment this to hide celery task succeeded/failed spam
    # e.g. "Task check_for_pruning[a1e96171-0ba8-4e00-887b-9fbf7442eab3] succeeded in 0.03137450001668185s: None"
    trace.logger.setLevel(logging.WARNING)


def set_task_finished_log_level(logLevel: int) -> None:
    """call this to override the setLevel in on_setup_logging. We are interested
    in the task timings in the cloud but it can be spammy for self hosted."""
    trace.logger.setLevel(logLevel)


class TenantContextFilter(logging.Filter):
    """Logging filter to inject tenant ID into the logger's name."""

    def filter(self, record: logging.LogRecord) -> bool:
        if not MULTI_TENANT:
            record.name = ""
            return True

        tenant_id = CURRENT_TENANT_ID_CONTEXTVAR.get()
        if tenant_id:
            # Match the 8 character tenant abbreviation used in OnyxLoggingAdapter
            tenant_id = tenant_id.split(TENANT_ID_PREFIX)[-1][:8]
            record.name = f"[t:{tenant_id}]"
        else:
            record.name = ""
        return True


@task_postrun.connect
def reset_tenant_id(
    sender: Any | None = None,  # noqa: ARG001
    task_id: str | None = None,  # noqa: ARG001
    task: Task | None = None,  # noqa: ARG001
    args: tuple[Any, ...] | None = None,  # noqa: ARG001
    kwargs: dict[str, Any] | None = None,  # noqa: ARG001
    **other_kwargs: Any,  # noqa: ARG001
) -> None:
    """Signal handler to reset tenant ID in context var after task ends."""
    CURRENT_TENANT_ID_CONTEXTVAR.set(POSTGRES_DEFAULT_SCHEMA)


def wait_for_document_index_or_shutdown() -> None:
    """
    Waits for the document index to become ready subject to a timeout.

    Raises WorkerShutdown if the timeout is reached.
    """
    if DISABLE_VECTOR_DB:
        logger.info("DISABLE_VECTOR_DB is set — skipping OpenSearch readiness check.")
        return

    # Imported here: opensearchpy costs ~18 MB and not every worker needs it.
    from onyx.document_index.opensearch.client import (
        wait_for_opensearch_with_timeout,
    )

    if not wait_for_opensearch_with_timeout():
        msg = "[OpenSearch] Readiness probe did not succeed within the timeout. Exiting..."
        logger.error(msg)
        raise WorkerShutdown(msg)


# File for validating worker liveness
class LivenessProbe(bootsteps.StartStopStep):
    requires = {"celery.worker.components:Timer"}

    def __init__(self, worker: Any, **kwargs: Any) -> None:
        super().__init__(worker, **kwargs)
        self.requests: list[Any] = []
        self.task_tref = None
        self.path = make_probe_path("liveness", worker.hostname)

    def start(self, worker: Any) -> None:  # ty: ignore[invalid-method-override]
        self.task_tref = worker.timer.call_repeatedly(
            15.0,
            self.update_liveness_file,
            (worker,),
            priority=10,
        )

    def stop(self, worker: Any) -> None:  # noqa: ARG002  # ty: ignore[invalid-method-override]
        self.path.unlink(missing_ok=True)
        if self.task_tref:
            self.task_tref.cancel()

    def update_liveness_file(self, worker: Any) -> None:  # noqa: ARG002
        self.path.touch()


def get_bootsteps() -> list[type]:
    return [LivenessProbe]


# Task modules that require a vector DB (OpenSearch).
# When DISABLE_VECTOR_DB is True these are excluded from autodiscover lists.
_VECTOR_DB_TASK_MODULES: set[str] = {
    "onyx.background.celery.tasks.connector_deletion",
    "onyx.background.celery.tasks.docprocessing",
    "onyx.background.celery.tasks.docfetching",
    "onyx.background.celery.tasks.pruning",
    "onyx.background.celery.tasks.vespa",
    "onyx.background.celery.tasks.cc_pair_ids_backfill",
    "onyx.background.celery.tasks.doc_permission_syncing",
    "onyx.background.celery.tasks.hierarchyfetching",
    # EE modules that are vector-DB-dependent
    "ee.onyx.background.celery.tasks.doc_permission_syncing",
    "ee.onyx.background.celery.tasks.external_group_syncing",
}
# NOTE: "onyx.background.celery.tasks.shared" is intentionally NOT in the set
# above. It contains celery_beat_heartbeat (which only writes to Redis) alongside
# document cleanup tasks. The cleanup tasks won't be invoked in minimal mode
# because the periodic tasks that trigger them are in other filtered modules.


def filter_task_modules(modules: list[str]) -> list[str]:
    """Remove vector-DB-dependent task modules when DISABLE_VECTOR_DB is True."""
    if not DISABLE_VECTOR_DB:
        return modules
    return [m for m in modules if m not in _VECTOR_DB_TASK_MODULES]
